import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

const axiosConf = {
  // 统一的配置
  options: {
    timeout: 60000,
    header: {},
  },


  // 请求前的处理
  beforeRequest (config: AxiosRequestConfig) {
    return config;
  },

  // 请求后的处理
  afterResponse (response: AxiosResponse) {
    return response;
  },

  // 结果统一处理, 使用code返回异常状态
  catchError (error: any) {
    let revert = 0;
    if (error.response) {
      // 服务器有响应
      revert = error.response.status;
    } else if (error.request) {
      // 请求已发送 服务器无响应
      revert = 600;
    } else {
      // 一些异常原因导致请求出错
      revert = 500;
    }
    return Promise.resolve({ data: { data: null, code: revert } });
  }
};


function Request (baseUrl: string) {
  // 请求示例
  const request = axios.create(Object.assign({ baseUrl}, axiosConf.options));
  // 请求前拦截
  request.interceptors.request.use(axiosConf.beforeRequest, axiosConf.catchError);
  // 请求后的拦截
  request.interceptors.response.use(axiosConf.afterResponse, axiosConf.catchError);

  return request;
}

export default Request;