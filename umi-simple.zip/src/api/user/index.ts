import { proxy } from './handler';
// import URI from 'urijs';
import * as apiVm from './apiVm';

export const accountLogin = (params: apiVm.LoginParamsType) => {
  return proxy.post('/api/login/account', params).then((res) => res.data);
}

export const getList = () => {
  return proxy.get('/api/datalist.json', {}).then((res) => res.data);
}