import React, { Component } from 'react';
import styles from './index.css';
import { connect } from 'dva';
// import { ConnectState } from '@/types/connect';
// @ts-ignore
@connect(({ user }: any ) => ({  user: user }))
class BasicLayout extends Component<any, any> {
  render () {
    return (
      <div className={styles.normal}>
        <h1 className={styles.title}>Yay! Welcome to umi!</h1>
      </div>
    );
  }
};

export default BasicLayout;
