import { getList } from '@/api/user/index';

export default {
  namespace: 'list',
  state: {
    list: []
  },

  reducers: {
    saveList (state: any, { payload }: any) {
      return {...state, ...payload};
    }
  },

  effects: {
    // 获取列表数据
    *fetchList ({ payload }: any, { call, put }: any) {
      const response = yield call(getList, payload);
      yield put({ type: 'saveList', payload: response });
    }
  }
}