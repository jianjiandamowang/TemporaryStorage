export default [
  // 主页
  {
    path: '/',
    component: '../layouts/BasicLayout',
    Routes: [],
    routes: [
      // 首页
      { path: '/', redirect: '/welcome' },
      // 欢迎页
      { path: '/welcome', name: 'welcome', icon: 'smile', component: './welcome' },
      // home
      {
        path: '/test',
        name: '测试',
        icon: 'smile',
        routes: [
          { path: '/test/home', name: '测试', icon: 'smile', component: './home/home' },
          { path: '/test/board', component: './home/board' },
        ]
      }
    ]
  },
  // user
  {   
    path: '/user',
    component: '../layouts/UserLayout',
    routes: [
      { name: 'login', path: '/user', component: './user/login', },
      { component: './404', },
    ],
  },
  {
    component: './404',
  },
]
