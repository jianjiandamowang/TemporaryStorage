
export interface UserModelState {
  currentUser?: any;
}

export interface GlobalModelState {
  collapsed: boolean;
}

export interface ConnectState {
  global: GlobalModelState;
  user: UserModelState;
}