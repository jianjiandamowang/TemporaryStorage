import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from 'H:/test/material/src/pages/.umi/LocaleWrapper.jsx';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__admin" */ '../../layouts/admin'),
        })
      : require('../../layouts/admin').default,
    Routes: [],
    routes: [
      {
        path: '/',
        redirect: '/admin/dashboard',
        exact: true,
        _title: 'umi-simple',
        _title_default: 'umi-simple',
      },
      {
        path: '/welcome',
        name: 'welcome',
        icon: 'smile',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__welcome" */ '../welcome'),
            })
          : require('../welcome').default,
        exact: true,
        _title: 'umi-simple',
        _title_default: 'umi-simple',
      },
      {
        path: '/admin',
        routes: [
          {
            path: '/admin/dashboard',
            name: '测试',
            icon: 'smile',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "layouts__admin" */ '../home/home'),
                })
              : require('../home/home').default,
            exact: true,
            _title: 'umi-simple',
            _title_default: 'umi-simple',
          },
          {
            component: () =>
              React.createElement(
                require('H:/test/material/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
            _title: 'umi-simple',
            _title_default: 'umi-simple',
          },
        ],
        _title: 'umi-simple',
        _title_default: 'umi-simple',
      },
      {
        component: () =>
          React.createElement(
            require('H:/test/material/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
        _title: 'umi-simple',
        _title_default: 'umi-simple',
      },
    ],
    _title: 'umi-simple',
    _title_default: 'umi-simple',
  },
  {
    path: '/user',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__UserLayout" */ '../../layouts/UserLayout'),
        })
      : require('../../layouts/UserLayout').default,
    routes: [
      {
        name: 'login',
        path: '/user',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__user__login" */ '../user/login'),
            })
          : require('../user/login').default,
        exact: true,
        _title: 'umi-simple',
        _title_default: 'umi-simple',
      },
      {
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__404" */ '../404'),
            })
          : require('../404').default,
        exact: true,
        _title: 'umi-simple',
        _title_default: 'umi-simple',
      },
      {
        component: () =>
          React.createElement(
            require('H:/test/material/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
        _title: 'umi-simple',
        _title_default: 'umi-simple',
      },
    ],
    _title: 'umi-simple',
    _title_default: 'umi-simple',
  },
  {
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () => import(/* webpackChunkName: "p__404" */ '../404'),
        })
      : require('../404').default,
    exact: true,
    _title: 'umi-simple',
    _title_default: 'umi-simple',
  },
  {
    component: () =>
      React.createElement(
        require('H:/test/material/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
    _title: 'umi-simple',
    _title_default: 'umi-simple',
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
