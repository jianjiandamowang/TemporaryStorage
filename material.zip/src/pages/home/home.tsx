import React from 'react';
import { Menu } from 'antd';
import router from 'umi/router';
import { connect } from 'dva';

// @ts-ignore
@connect(({list}) => ({list}))
class TestPage extends React.Component<any> {

  constructor (props: any) {
    super(props);
    console.log(props);
  }

  LinkTo (event: any) {
    let { key } = event;
    router.push(key);
  }

  componentDidMount () {
    const { dispatch } = this.props;
    dispatch({ type: 'list/fetchList', payload: {} });
  }

  render() {
    let { location } = this.props;
    const pathname = location.pathname;
    return (
      <div>
        <Menu
          theme="dark"
          mode="horizontal"
          defaultSelectedKeys={[pathname]}
          style={{ lineHeight: '64px' }}
        >
          <Menu.Item key="/test/board" onClick={this.LinkTo}>test1</Menu.Item>
          <Menu.Item key="/test/home" onClick={this.LinkTo}>test2</Menu.Item>
          <Menu.Item key="3" onClick={this.LinkTo}>test3</Menu.Item>
        </Menu>
        <div>getList api</div>
        <div>{JSON.stringify(this.props.list)}</div>
      </div>
    )
  }
}

export default TestPage;
