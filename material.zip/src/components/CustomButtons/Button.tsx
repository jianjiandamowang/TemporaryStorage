import React from 'react';
import classNames from "classnames";
import Button from "@material-ui/core/Button";

import { makeStyles } from '@material-ui/core/styles';

import styles from "@/assets/jss/component/buttonStyle.js";


interface RegularButtonProps {
  color: "info" | "success" | "warning" | "danger" | "rose" | "white" | "transparent";
  size: "sm" | "lg";
  simple: Boolean;
  round: Boolean;
  disabled: Boolean;
  block: Boolean;
  link: Boolean;
  justIcon: Boolean;
  className: String;
  // use this to pass the classes props from Material-UI
  muiClasses: Object,
  children: React.ReactNode;
}

const useStyles = makeStyles(styles);

const RegularButton: React.SFC<RegularButtonProps> = props => {
  const classes = useStyles();
  const {
    color,
    round,
    children,
    disabled,
    simple,
    size,
    block,
    link,
    justIcon,
    className,
    muiClasses,
    ...rest
  } = props;
  const btnClasses = classNames({
    [classes.button]: true,
    [classes[size]]: size,
    [classes[color]]: color,
    [classes.round]: round,
    [classes.disabled]: disabled,
    [classes.simple]: simple,
    [classes.block]: block,
    [classes.link]: link,
    [classes.justIcon]: justIcon,
    [className]: className
  });
  return (
    <Button {...rest} className={btnClasses} classes={muiClasses}>
      {children}
    </Button>
  )
}

export default RegularButton;