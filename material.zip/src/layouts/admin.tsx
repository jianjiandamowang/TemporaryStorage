import React from 'react';

import bgImage from "@/assets/img/sidebar-2.jpg";
import logo from "@/assets/img/reactlogo.png";

import { makeStyles } from "@material-ui/core/styles";

import Navbar from "@/components/MaterialComponent/Navbars/Navbar";
import Sidebar from "@/components/MaterialComponent/SideBar/SideBar";


import Dashboard from "@material-ui/icons/Dashboard";
import Person from "@material-ui/icons/Person";

import styles from "@/assets/jss/layouts/adminStyle.js";

const useStyles = makeStyles(styles);

const Admin: React.SFC<any> = props => {
  const classes = useStyles();
  const [image, setImage] = React.useState(bgImage);
  const [color, setColor] = React.useState("blue");
  const [mobileOpen, setMobileOpen] = React.useState(false);
  
  const routes = [
    {
      path: "/dashboard",
      name: "Dashboard",
      rtlName: "لوحة القيادة",
      icon: Dashboard,

      layout: "/admin"
    },
    {
      path: "/user",
      name: "User Profile",
      rtlName: "ملف تعريفي للمستخدم",
      icon: Person,
      layout: "/admin"
    },
    {
      path: "/welcome",
      name: "建建",
      rtlName: "قائمة الجدول",
      icon: "content_paste",
      layout: "/admin"
    },
  ]

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  }

  return (
    <div className={classes.wrapper}>
      <Sidebar
        routes={routes}
        logoText={"Creative Tim"}
        logo={logo}
        image={image}
        handleDrawerToggle={handleDrawerToggle}
        open={mobileOpen}
        color={color}
        {...props}
      />

      <div className={classes.mainPanel}> 
        <div className={classes.content}>
          {props.children}
        </div>
        <Navbar
            routes={routes}
            handleDrawerToggle={handleDrawerToggle}
            {...props}
          />
      </div>

    </div>
  )
}


export default Admin;