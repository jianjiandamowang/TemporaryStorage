import AxiosProxy from '@/lib/axios.proxy';
export const proxy = AxiosProxy('');