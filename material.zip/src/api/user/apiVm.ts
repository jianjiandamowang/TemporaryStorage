export interface LoginParamsType {
  userName: string;
  password: string;
  mobile: string;
  captcha: string;
}