export default [
  // 主页
  {
    path: '/',
    component: '../layouts/admin',
    Routes: [],
    routes: [
      // 首页
      { path: '/', redirect: '/admin/dashboard' },
      // 欢迎页
      { path: '/welcome', name: 'welcome', icon: 'smile', component: './welcome' },
      // admin
      {
        path: '/admin',
        routes: [
          { path: '/admin/dashboard', name: '测试', icon: 'smile', component: './home/home' },
        ]
      }
    ]
  },

  // user
  {   
    path: '/user',
    component: '../layouts/UserLayout',
    routes: [
      { name: 'login', path: '/user', component: './user/login', },
      { component: './404', },
    ],
  },
  {
    component: './404',
  },
]
