import { IConfig, IPlugin } from 'umi-types';
import slash from 'slash2';
// 载入路由配置
import routerConfig from './router.config';

// 插件配置
const plugins: IPlugin[] = [
  // ref: https://umijs.org/plugin/umi-plugin-react.html
  ['umi-plugin-react', {
    antd: true,
    dva: true,
    dynamicImport: { webpackChunkName: true },
    title: 'umi-simple',
    dll: true,
    locale: {
      enable: true,
      default: 'en-US',
    },
    routes: {
      exclude: [
        /models\//,
        /services\//,
        /model\.(t|j)sx?$/,
        /service\.(t|j)sx?$/,
        /components\//,
      ],
    },
  }],
];


export default {
  treeShaking: true,
  plugins: plugins,
  // 配置式路由
  routes: routerConfig,
  // 禁止 redirect 上提
  disableRedirectHoist: true,

  lessLoaderOptions: {
    javascriptEnabled: true,
  },
  cssLoaderOptions: {
    modules: true,
    getLocalIdent: (
      context: {
        resourcePath: string;
      },
      _: string,
      localName: string,
    ) => {
      if (
        context.resourcePath.includes('node_modules') ||
        context.resourcePath.includes('ant.design.pro.less')
        // context.resourcePath.includes('global.less')
      ) {
        return localName;
      }

      const match = context.resourcePath.match(/src(.*)/);

      if (match && match[1]) {
        const antdProPath = match[1].replace('.less', '');
        const arr = slash(antdProPath)
          .split('/')
          .map((a: string) => a.replace(/([A-Z])/g, '-$1'))
          .map((a: string) => a.toLowerCase());
        return `antd-pro${arr.join('-')}-${localName}`.replace(/--/g, '-');
      }

      return localName;
    },
  },
  targets: {
    ie: 11,
  },
  devtool: 'cheap-module-eval-source-map',
  proxy: {
    '/api/': {
      target: 'https://preview.pro.ant.design/',
      changeOrigin: true,
    },
  },

} as IConfig;
