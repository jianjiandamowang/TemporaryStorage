export default {
  '/api/datalist.json': [
    {  id: 1, name: '建建', age: 18, Level: 100, job: '魔王' }
  ]
}